<?php $__env->startSection('title', 'Laporan Harian'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="fw-bold mb-0">Rekapitulasi Laporan Harian</h5>
    </div>
    <div>
        <button class="btn btn-outline-danger me-2" onclick="alert('Fitur Export PDF akan segera hadir')"><i class="bi bi-file-earmark-pdf"></i> Export PDF</button>
        <button class="btn btn-outline-success" onclick="alert('Fitur Export Excel akan segera hadir')"><i class="bi bi-file-earmark-excel"></i> Export Excel</button>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Tanggal</th>
                        <th>Lokasi Proyek</th>
                        <th>Total Hadir</th>
                        <th>Unit Aktif</th>
                        <th>Unit Idle</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="ps-4 fw-bold"><?php echo e($lap->tanggal->format('d M Y')); ?></td>
                        <td><?php echo e($lap->lokasi->nama); ?></td>
                        <td><?php echo e($lap->total_hadir); ?> Orang</td>
                        <td><span class="badge bg-success"><?php echo e($lap->total_unit_aktif); ?> Unit</span></td>
                        <td><span class="badge bg-warning text-dark"><?php echo e($lap->total_unit_idle); ?> Unit</span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\antigravity\elegant-salk\resources\views/pimpinan/laporan.blade.php ENDPATH**/ ?>