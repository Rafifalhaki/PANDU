<?php $__env->startSection('title', 'Manajemen Absensi'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('pimpinan.absensi')); ?>" method="GET" class="row g-3 align-items-center">
            <div class="col-auto">
                <label class="col-form-label">Filter Lokasi:</label>
            </div>
            <div class="col-auto">
                <select name="lokasi_id" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Lokasi</option>
                    <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loc->id); ?>" <?php echo e(request('lokasi_id') == $loc->id ? 'selected' : ''); ?>><?php echo e($loc->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Nama Mandor</th>
                        <th>Lokasi Proyek</th>
                        <th>Waktu Masuk</th>
                        <th>Waktu Pulang</th>
                        <th>Koordinat Masuk</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="ps-4 fw-bold"><?php echo e($absen->user->name); ?></td>
                        <td><?php echo e($absen->lokasi->nama); ?></td>
                        <td><?php echo e($absen->waktu_masuk->format('d/m/Y H:i')); ?></td>
                        <td><?php echo e($absen->waktu_pulang ? $absen->waktu_pulang->format('d/m/Y H:i') : '-'); ?></td>
                        <td><small class="text-muted"><?php echo e($absen->koordinat_masuk); ?></small></td>
                        <td>
                            <?php if($absen->is_offline): ?>
                                <span class="badge bg-warning text-dark"><i class="bi bi-wifi-off"></i> Sync Offline</span>
                            <?php else: ?>
                                <span class="badge bg-success"><i class="bi bi-wifi"></i> Online</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\antigravity\elegant-salk\resources\views/pimpinan/absensi.blade.php ENDPATH**/ ?>