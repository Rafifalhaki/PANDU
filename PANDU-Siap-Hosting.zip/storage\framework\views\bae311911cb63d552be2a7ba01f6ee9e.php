<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <div class="d-flex justify-content-between">
                    <h5 class="fw-bold">Manajemen Pengguna</h5>
                    <button class="btn btn-sm btn-primary"><i class="bi bi-plus"></i></button>
                </div>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center px-0 border-bottom-0" style="border-bottom: 1px solid #eee !important;">
                        <div>
                            <h6 class="mb-0 fw-bold"><?php echo e($user->name); ?></h6>
                            <small class="text-muted"><?php echo e($user->email); ?></small>
                        </div>
                        <span class="badge bg-<?php echo e($user->role == 'pimpinan' ? 'primary' : 'secondary'); ?>"><?php echo e(ucfirst($user->role)); ?></span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pt-4">
                <div class="d-flex justify-content-between">
                    <h5 class="fw-bold">Manajemen Lokasi Proyek</h5>
                    <button class="btn btn-sm btn-primary"><i class="bi bi-plus"></i></button>
                </div>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item px-0 border-bottom-0" style="border-bottom: 1px solid #eee !important;">
                        <div class="d-flex justify-content-between mb-1">
                            <h6 class="mb-0 fw-bold"><?php echo e($loc->nama); ?></h6>
                            <small class="text-muted"><?php echo e($loc->radius_meter); ?>m</small>
                        </div>
                        <small class="text-muted"><?php echo e($loc->lat); ?>, <?php echo e($loc->lng); ?></small>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\antigravity\elegant-salk\resources\views/pimpinan/pengaturan.blade.php ENDPATH**/ ?>