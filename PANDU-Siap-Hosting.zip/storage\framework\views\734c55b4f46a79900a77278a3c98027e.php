<?php $__env->startSection('title', 'Dashboard Utama'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="text-muted fw-semibold">Mandor Hadir Hari Ini</h6>
                <h3 class="fw-bold"><?php echo e($totalHadir); ?> <i class="bi bi-person-check-fill text-success fs-4 float-end"></i></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="text-muted fw-semibold">Total Lokasi Aktif</h6>
                <h3 class="fw-bold"><?php echo e($totalLokasi); ?> <i class="bi bi-geo-alt-fill text-primary fs-4 float-end"></i></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="text-muted fw-semibold">Unit Alat Berat Aktif</h6>
                <h3 class="fw-bold"><?php echo e($totalUnitAktif); ?> <i class="bi bi-truck text-info fs-4 float-end"></i></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm <?php echo e($idleCount > 0 ? 'bg-danger text-white' : ''); ?>">
            <div class="card-body">
                <h6 class="<?php echo e($idleCount > 0 ? 'text-white' : 'text-muted'); ?> fw-semibold">Unit Idle (> 3 Jam)</h6>
                <h3 class="fw-bold"><?php echo e($idleCount); ?> <i class="bi bi-exclamation-triangle-fill <?php echo e($idleCount > 0 ? 'text-warning' : 'text-secondary'); ?> fs-4 float-end"></i></h3>
            </div>
        </div>
    </div>
</div>

<?php if($idleCount > 0): ?>
<div class="alert alert-danger shadow-sm border-0 mb-4">
    <h5 class="alert-heading"><i class="bi bi-exclamation-octagon-fill"></i> Peringatan Unit Idle!</h5>
    <p class="mb-0">Terdapat unit alat berat yang berstatus idle lebih dari 3 jam:</p>
    <ul class="mb-0 mt-2">
        <?php $__currentLoopData = $idleAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><strong><?php echo e($alert->nama_unit); ?></strong> (<?php echo e($alert->lokasi->nama); ?>) - Terakhir terlihat: <?php echo e($alert->last_seen->diffForHumans()); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 pt-4 pb-0">
                <h5 class="fw-bold">Kehadiran Mandor per Lokasi</h5>
            </div>
            <div class="card-body">
                <canvas id="kehadiranChart" height="100"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 pt-4 pb-0">
                <h5 class="fw-bold">Aktivitas Terbaru</h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $recentAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-group-item py-3 border-bottom-0">
                        <div class="d-flex w-100 justify-content-between mb-1">
                            <h6 class="mb-0 fw-bold"><?php echo e($absen->user->name); ?></h6>
                            <small class="text-muted"><?php echo e($absen->waktu_masuk->format('H:i')); ?></small>
                        </div>
                        <p class="mb-1 small"><?php echo e($absen->lokasi->nama); ?></p>
                        <?php if($absen->waktu_pulang): ?>
                            <span class="badge bg-secondary">Sudah Pulang</span>
                        <?php else: ?>
                            <span class="badge bg-success">Hadir</span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-4 text-center text-muted">Belum ada aktivitas hari ini.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const ctx = document.getElementById('kehadiranChart').getContext('2d');
    const chartData = <?php echo json_encode($chartData, 15, 512) ?>;
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.labels,
            datasets: [
                {
                    label: 'Aktual Hadir',
                    data: chartData.actual,
                    backgroundColor: '#1F4E79',
                },
                {
                    label: 'Target Mandor',
                    data: chartData.planned,
                    backgroundColor: '#E87722',
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\antigravity\elegant-salk\resources\views/pimpinan/dashboard.blade.php ENDPATH**/ ?>