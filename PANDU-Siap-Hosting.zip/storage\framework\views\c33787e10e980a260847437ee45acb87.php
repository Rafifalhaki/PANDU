<?php $__env->startSection('title', 'Tracking Unit Alat Berat'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between mb-4">
            <h5 class="fw-bold">Daftar Unit</h5>
            <button class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Unit</button>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Nama Unit</th>
                        <th>Tipe</th>
                        <th>Lokasi Terakhir</th>
                        <th>Status</th>
                        <th>Terakhir Terlihat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e(($unit->status == 'idle' && $unit->last_seen && $unit->last_seen->diffInHours(now()) >= 3) ? 'table-warning' : ''); ?>">
                        <td class="fw-bold"><?php echo e($unit->nama_unit); ?></td>
                        <td><?php echo e($unit->tipe); ?></td>
                        <td><?php echo e($unit->lokasi->nama); ?></td>
                        <td>
                            <?php if($unit->status == 'aktif'): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php elseif($unit->status == 'idle'): ?>
                                <span class="badge bg-warning text-dark">Idle</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Offline</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($unit->last_seen ? $unit->last_seen->diffForHumans() : '-'); ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\antigravity\elegant-salk\resources\views/pimpinan/tracking.blade.php ENDPATH**/ ?>